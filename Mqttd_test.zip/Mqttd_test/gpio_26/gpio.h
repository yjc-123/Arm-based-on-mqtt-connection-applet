#ifdef		_GPIO_H_
#define 	_GPIO_H_

int gpio_act(const struct mosquitto_message *msg);

#endif
