#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "iniparser.h"
#include "dictionary.h"
#include <errno.h>
struct Conf{
	int port;
	char hostname[128];
	char username[128];
	int MSG_MAX_SIZE;
	char password[128];
	int Qos;
	int keepalive;
	char file_log[128];
	char Topic[128];
	
};

struct Conf* parser_conf(char *conf_file){
	struct Conf *conf;
	dictionary	*ini;
	char		*str;
	ini = iniparser_load(conf_file);
	
	conf = (struct Conf*)malloc(10*sizeof(struct Conf));
	
	memset(conf, 0 ,sizeof(conf));
	/*****************************
	 *	get file_log         *
	 * **************************/
	
	str = iniparser_getstring(ini, "Log:file_log", "null");
	
	//conf->file_log = (char*)malloc(strlen(str)+1);

	
	int out = open(str, O_APPEND|O_RDWR,0644);
	dup2(out, STDOUT_FILENO);
	
	if(str && strlen(str)){
		strncpy(conf->file_log, str, sizeof(conf->file_log));
		printf("get file_log[%s] successful\n",str);	
		
	}

	/***************************
	 *	get port	   *
	 **************************/
	conf->port = iniparser_getint(ini, "Server:port", -1);
	if(conf->port == -1)
	{
		printf("get port is failed[%d]",strerror(errno));
	}
	else{
		printf("get port[%d] successful\n",conf->port);
	}
 	
	/**************************
	 *   get hostname 	  *
	 *************************/	
       	str = iniparser_getstring(ini, "Server:hostname", "null");
        //conf->hostname = (char*)malloc(strlen(str)+1);
	if(str == "null"){
		printf("get hostname is faild\n");
	}
	else{
		strncpy(conf->hostname, str, sizeof(conf->hostname));
		printf("get hostname[%s] is successful\n",conf->hostname);
	}

	/********************
         *   get username   *
         *******************/   
	str = iniparser_getstring(ini, "Mqtt:username", "null");
        //conf->username = (char *)malloc(strlen(str)+1);
	if(str == "null"){
		printf("get username is failed\n");
	}
	else{
		strncpy(conf->username, str, sizeof(conf->username));
		printf("get username[%s] is successful\n",conf->username);
	}

	/********************
         *   get SIZE   *
         *******************/   
	conf->MSG_MAX_SIZE = iniparser_getint(ini, "Size:msg_size", -1);
        if(conf->MSG_MAX_SIZE == -1){
		printf("get size is failed\n");
	}
	else{
		printf("get size[%d] is successful\n",conf->MSG_MAX_SIZE);
	}

	/********************
         *   get password   *
         *******************/   
        str  = iniparser_getstring(ini, "Mqtt:password", "null");
	//conf->password = (char*)malloc(strlen(str)+1);
	if(str == "null"){
		printf("get password failed\n");
			
	}
	else{
		strncpy(conf->password, str, sizeof(conf->password));
		printf("get password[%s] successful\n",conf->password);
	}
	
	/********************
         *   get Qos	   *
         *******************/   
	conf->Qos = iniparser_getint(ini, "Mqtt:Qos", -1);
        printf("2");
	if(conf->Qos == -1){
		printf("get Qos is faild\n");
	}
	else{
		printf("get Qos[%d] is successful\n",conf->Qos);
	}

	/********************
         *   get keepalive  *
         *******************/   
	conf->keepalive = iniparser_getint(ini, "Mqtt:keepalive", -1);
        if(conf->keepalive == -1){
		printf("get keepalive is failed\n");
	}
	else{
		printf("get keepalive[%d] successful\n",conf->keepalive);
	}
	
	/********************
         *   get topic   *
         *******************/   
        str = iniparser_getstring(ini, "Topic:Topic", "null");	
	//conf->Topic = (char*)malloc(strlen(str)+1);
	if(str == "null"){
		printf("get topic is faild\n");
	}
	else{
		strncpy(conf->Topic, str, sizeof(conf->Topic));
		printf("get topic[%s] is successful\n",conf->Topic);
	}
	close(out);
	return conf;

}


