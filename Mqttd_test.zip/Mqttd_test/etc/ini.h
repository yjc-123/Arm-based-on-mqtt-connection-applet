#ifndef _INI_H_
#define _INI_H_

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "iniparser.h"
#include "dictionary.h"
#include <errno.h>
struct Conf{
        int port;
        char hostname[128];
        char username[128];
        int MSG_MAX_SIZE;
        char password[128];
        int Qos;
        int keepalive;
        char file_log[128];
        char Topic[128];

};

struct Conf *parser_conf(char *conf_file);

#endif
